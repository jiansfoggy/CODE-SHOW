#include "HexHistogram.h"

using namespace std;

// This is constructor
HexHistogram::HexHistogram(std::string filename)
{
	std::ifstream istrm(filename);
	// Check if the file is loaded successfully.
	if (!istrm.is_open()) {
		cerr << "failed to open " << filename << '\n';
	}
	else
	{
		string loaded_line;
		// Get line from loading file
		while(getline(istrm, loaded_line))
		{
			Line_Number++;
			// Extract elements from loaded line and convert it into hex type 
			// and save them into map based on convenient type.
			std::istringstream iss(loaded_line);
			uint32_t Hex_Number;
			uint32_t Min_This_Line = UINT_MAX;
			while(iss>>std::hex>> Hex_Number)
			{
				Value_Count++;
				All_Numbers.push_back(Hex_Number);
				Min_This_Line =(Hex_Number<Min_This_Line)?Hex_Number:Min_This_Line;
			}
			Min_Each_Line.insert({ Line_Number, Min_This_Line });
		}
	}
    istrm.close();
	form_map(All_Numbers);
}

HexHistogram::~HexHistogram(){
	// delete maps and clean the memory
	transit_map.clear();
	Min_Each_Line.clear();
}

void HexHistogram::form_map(vector<uint32_t> All_Numbers){
	for (uint32_t i:All_Numbers)
	{
		if(transit_map.count(i))
		{
			transit_map[i]+=1;
		}
		else
		{
			transit_map.insert({ i, 1 }); ;
		}
	}
}

uint32_t HexHistogram::get_value_count(){
	cout<<"Number of values read: "<<Value_Count<<endl;
	return Value_Count;
}

uint32_t HexHistogram::get_unique_value_count(){
	Unique_Count = transit_map.size();
	cout<<"Number of unique values read: "<<Unique_Count<<endl;
	return Unique_Count;
}

uint32_t HexHistogram::get_line_count(){
	cout<<"Number of lines: "<<Line_Number<<endl;
	return Line_Number;
}

uint32_t HexHistogram::get_smallest_number(uint32_t x){
	if(x<0 || x>Line_Number){
		cerr << "Logic Error. \n";
		exit(1);
	}
	return Min_Each_Line.at(x);
}

void HexHistogram::print(){
	cout<<"Histogram"<<endl;
	map<uint32_t, uint32_t>::iterator it = transit_map.begin();
	while (it != transit_map.end())
	{
		std::stringstream stream;
		stream << std::hex << (*it).first;
		std::string hexString = stream.str();
		cout<< std::right <<setw(8)<<hexString<<":"<<setw(8)<<(*it).second<<endl;
		it++;
	}
}
