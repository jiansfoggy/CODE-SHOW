#ifndef HEXHISTOGRAM_H
#define HEXHISTOGRAM_H
#include <cstdint>
#include <string>
#include <sstream>
#include <stdio.h>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
#include <climits>
#include <map>
using std::setw;
using namespace std;

class HexHistogram
{
	public:
		HexHistogram(std::string filename);
		~HexHistogram();
		uint32_t get_value_count(); //returns the total number of values in the file (type uint32_t).
		uint32_t get_unique_value_count(); //returns the number of unique values in the file (type uint32_t).
		uint32_t get_line_count(); //returns the number of lines in the file (type uint32_t).
		uint32_t get_smallest_number(uint32_t Line_Number); //returns the smallest value in the line (as an uint32_t).
		void print(); //print the histogram contents.
		void form_map(std::vector<uint32_t> All_Numbers); // insert value into map one by one.
	private:
		// Define the variables and parameters that will be used by those public functions
		vector<uint32_t> All_Numbers;
		map<uint32_t,uint32_t> Min_Each_Line;
		int Value_Count = 0;
		int Unique_Count = 0;
		int Line_Number = 0;
		map<uint32_t,uint32_t> transit_map;
};
#endif // HEXHISTOGRAM_H
