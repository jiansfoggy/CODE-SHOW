#include "HexHistogram.h"

int main (int argc, char *argv[]){
   // Error Report for wrong number of input arguments
    if (argc != 2) {
      cerr << "Please write down sth like an input address.\n";
      exit(1);
    }
    // Create an object of class HexHistogram and  Read file into it
	HexHistogram* h = new HexHistogram(argv[1]);
    // Print out the required 5 output
	(*h).get_value_count();
	(*h).get_unique_value_count();
	int Line_Num = (*h).get_line_count();

	cout<<"Smallest number on each line"<<endl;
	for(int i=Line_Num; i>0; i--)
		{
			uint32_t Min_This_Line = (*h).get_smallest_number(i);
			std::stringstream stream;
			stream << std::hex << Min_This_Line;
			cout<<std::right<<setw(4)<<i<<":"<<setw(8)<<stream.str()<<endl;
		}

	(*h).print();
	(*h).~HexHistogram();
}
