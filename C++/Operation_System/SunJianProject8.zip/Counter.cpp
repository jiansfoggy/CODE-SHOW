// Jian Sun Project 8 -- Page System Simulation
// Counter Class

#include "Counter.h"

Counter::Counter()
{
	COUNTER=0;
}
		
Counter::~Counter()
{
	
}

void Counter::add_CNT(int PUNCH)
{
	for (int j=0; j<7; j++)
	{
		cnt8[j]=cnt8[j+1];
	}
	cnt8[7]=PUNCH;
	COUNTER=cnt8.count();
}

uint8_t Counter::get_CNT()
{
	return COUNTER;
}

void Counter::reset()
{
	cnt8.reset();
	COUNTER=0;
}

void Counter::pnt_CNT(int FORMAT)
{
	if (FORMAT==1) cout<<COUNTER<<endl;
	else if (FORMAT==2) cout<<cnt8<<endl;
	else 
	{
		cerr<<"Wrong index here."<<endl;
		exit(1);
	}
}