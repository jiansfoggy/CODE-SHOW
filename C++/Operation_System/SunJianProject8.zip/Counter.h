// Jian Sun Project 8 -- Page System Simulation
// Counter Class

#ifndef COUNTER_H
#define COUNTER_H

#include <list>
#include <cmath> 
#include <bitset>
#include <vector>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <cstdlib>
#include <iostream>
#include <unistd.h>
#include <stdlib.h>
#include <algorithm>

using std::setw;
using std::bitset;
using namespace std;

class Counter
{
public:
	Counter();						// Counter's constructor. It has no argument.
	~Counter();
	void add_CNT(int PUNCH);		// the function to make changes for COUNTER and cnt8
	uint8_t get_CNT();				// return the variable COUNTER
	void reset();					// reset the Counter for evicting pages
	void pnt_CNT(int FORMAT);		// print the Counter

private:
	uint8_t COUNTER;				// the required private variable: COUNTER
	bitset<8> cnt8;					// this variable can help us to output value in binary
};

#endif // COUNTER_H