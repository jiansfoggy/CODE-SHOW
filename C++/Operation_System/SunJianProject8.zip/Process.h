// Jian Sun Project 8 -- Page System Simulation
// Process Class

#ifndef PROCESS_H
#define PROCESS_H

#include<map>
#include "Counter.h"
#include "PageTableEntry.h"

using namespace std;

class Process
{
	friend class PagingSimulator;								// PagingSimulator is the friend class of Process, so PagingSimulator can use page table and counter set

public:
	Process(uint32_t PN=0, uint32_t FN=0);						// Constructor. The first argument is page number, the second argument is frame number
	~Process();													// release memory
	uint32_t PAGE_NUM;
	uint32_t FRAME_NUM;
	PageTableEntry* transit_table;								// define page table entry variable for each pages of this process
	PageTableEntry *Page_Table = new PageTableEntry[100];		// define dynamic array to store page table entry for all pages of this process
	map<uint32_t, Counter> cnt_set;								// define a set of counters
	void print_process();										// a function to print all Page_Table and counter set values within this process
};

#endif // PROCESS_H