// Jian Sun Project 8 -- Page System Simulation
// PagingSimulator Class

#include "PagingSimulator.h"

PagingSimulator::PagingSimulator(string fn)
{
	filename=fn;
}
		
PagingSimulator::~PagingSimulator()
{
	delete[] P_list;
	frame_list.clear();
}

bool PagingSimulator::check_load(uint32_t PRON, uint32_t PN)
{
	return P_list[PRON].Page_Table[PN].get_load();
}

void PagingSimulator::modify_frame_list(uint32_t PRON, uint32_t FN, uint32_t PN, Counter c)
{
	for (auto i:frame_list)
	{
		if (get<0>(i.second)==FN)
		{
			// feedback the process number and page number for evicting one
			uint32_t PRO_DELETE=get<0>(i.first);
			uint32_t PAGE_NOW = get<1>(i.first);
			
			// if new inserted page is not loaded, we will reset the evicted page 
			if (!check_load(PRON,PN)) 
			{
				P_list[PRO_DELETE].cnt_set[PAGE_NOW].reset();
				P_list[PRO_DELETE].Page_Table[PAGE_NOW].reset();
			}

			// delete the evicted one. 
			tuple<uint32_t,uint32_t> drop_this = make_tuple(PRO_DELETE, PAGE_NOW);
			frame_list.erase(drop_this);
		}
	}
	frame_list.insert({make_tuple(PRON,PN),make_tuple(FN,c.get_CNT())});
}

uint32_t PagingSimulator::sort_frame_list(map<tuple<uint32_t,uint32_t>, tuple<uint32_t,uint8_t>> FLST)
{
	uint32_t MIN_FRAME=UINT32_MAX;
	uint8_t  MIN_CNT  =UINT8_MAX;

	// find the min count number and related frame number is the one that we 
	// need to evict
	for (auto fl:frame_list)
	{
		get<1>(fl.second)=P_list[get<0>(fl.first)].cnt_set[get<1>(fl.first)].get_CNT();
		if(get<1>(fl.second) < MIN_CNT)
		{
			MIN_FRAME=get<0>(fl.second);
			MIN_CNT  =get<1>(fl.second);
			PRO_DROP =get<0>(fl.first);
			PAGE_DROP=get<1>(fl.first);
		}
	}
	return MIN_FRAME;
}

void PagingSimulator::find_insert_pos(uint32_t PRON, uint32_t PN)
{
	// when frame_list's size is less than frame number
	// we would just choose the next index
	if(frame_list.empty())
	{
		FRAME_FOR_LOAD=FRAME_INEX;
		FRAME_INEX++;
	} else if(frame_list.size()>0 && frame_list.size()<FRAME_NUMBER)
	{
		FRAME_FOR_LOAD=FRAME_INEX;
		FRAME_INEX++;
	} else if(frame_list.size()==FRAME_NUMBER)
	{
		// when frame_list's size is equal to frame number
		// we just feedback the frame that we have to evict
		FRAME_FOR_LOAD=sort_frame_list(frame_list);
		cout<<"Evicting process "<<PRO_DROP<<" page "<<PAGE_DROP<<endl;	
		if (P_list[PRO_DROP].Page_Table[PAGE_DROP].get_M()==1)
		{
			cout<<"Writing frame "<<FRAME_FOR_LOAD<<" back to disk:"<<endl;
		}
	} else cout<<"Wrong Input"<<endl;
}

void PagingSimulator::operate(string task, uint32_t PN)
{
	if (check_load(PRO_NUM,PN)) 
	{
		// if this page is currently loaded, we do the following
		if (task=="r") 
		{
			P_list[PRO_NUM].Page_Table[PN].new_R(1);
		}
		if (task=="w") 
		{
			P_list[PRO_NUM].Page_Table[PN].new_R(1);
			P_list[PRO_NUM].Page_Table[PN].new_M(1);
		}

	} else
	{	// if this page isn't currently loaded, we do the following
		P_list[PRO_NUM].Page_Table[PN].reset();
		P_list[PRO_NUM].cnt_set[PN].reset();
		P_list[PRO_NUM].Page_Table[PN].page_num(PN);
		if (task=="r") 
		{
			P_list[PRO_NUM].Page_Table[PN].new_R(1);
		}
		if (task=="w") 
		{
			P_list[PRO_NUM].Page_Table[PN].new_R(1);
			P_list[PRO_NUM].Page_Table[PN].new_M(1);
		}
		P_list[PRO_NUM].Page_Table[PN].frame_num(FRAME_FOR_LOAD);
		modify_frame_list(PRO_NUM, FRAME_FOR_LOAD, PN, P_list[PRO_NUM].cnt_set[PN]);
	}
	P_list[PRO_NUM].Page_Table[PN].new_P(1);	
	P_list[PRO_NUM].Page_Table[PN].new_load();

	ROUND_CNT++;

	// update the counter every other instruction
	if (ROUND_CNT==2)
	{
		for (auto j:frame_list)
		{
			if(get<0>(j.second)==FRAME_FOR_LOAD)
			{
				P_list[get<0>(j.first)].cnt_set[get<1>(j.first)].add_CNT(1);
				P_list[get<0>(j.first)].Page_Table[get<1>(j.first)].new_R(0);
				get<1>(j.second)=P_list[get<0>(j.first)].cnt_set[get<1>(j.first)].get_CNT();
			} else if (get<0>(j.second)==LAST_FN)
			{
				P_list[get<0>(j.first)].cnt_set[get<1>(j.first)].add_CNT(1);
				P_list[get<0>(j.first)].Page_Table[get<1>(j.first)].new_R(0);
				get<1>(j.second)=P_list[get<0>(j.first)].cnt_set[get<1>(j.first)].get_CNT();
			} else
			{
				P_list[get<0>(j.first)].cnt_set[get<1>(j.first)].add_CNT(0);
				P_list[get<0>(j.first)].Page_Table[get<1>(j.first)].new_R(0);
				get<1>(j.second)=P_list[get<0>(j.first)].cnt_set[get<1>(j.first)].get_CNT();
			}
		}
		ROUND_CNT=0;
	}

	// record the process number, page number and frame number that we used this time
	// for future counter updating 
	LAST_FN=FRAME_FOR_LOAD;
	LAST_PN=PN;
	LAST_PRO=PRO_NUM;
}

void PagingSimulator::run()
{
	// read file
	ifstream file_stream(filename);
	if(!file_stream.is_open())
	{
		cerr << "failed to open " << filename << endl;
		exit(1);
	} else
	{
		string loaded_line;
		uint32_t LST_SIZE;
		while(getline(file_stream, loaded_line))
		{
			istringstream iss(loaded_line);
			// load the first two lines and print the initialized table
			if (LINE_NUM==1)
			{
				iss>>PAGE_NUMBER;
				iss>>FRAME_NUMBER;
				iss>>PAGE_SIZE;
				cout<<"INITIAL TABLE SETUP:"<<endl;
				cout<<"Virtual Memory Size: "<<PAGE_NUMBER*PAGE_SIZE<<endl;
				cout<<"Physical Memory Size: "<<FRAME_NUMBER*PAGE_SIZE<<endl;
				cout<<"Page Size: "<<PAGE_SIZE<<endl;
			} else if (LINE_NUM==2)
			{
				iss>>PRO_NUM;
				cout<<"Number of Processes: "<<PRO_NUM<<endl;
				cout<<"Number of Pages: "<<PAGE_NUMBER<<endl;
				cout<<"Number of Frames: "<<FRAME_NUMBER<<endl;
				cout<<"Page Tables (with aging status)"<<endl;
				LST_SIZE=PRO_NUM;
				for (uint32_t i=0; i<PRO_NUM; i++)
				{
					Process* p_x = new Process(PAGE_NUMBER, FRAME_NUMBER);
					P_list[i]=*p_x;
					cout<<"Process "<<i<<endl;
					p_x->print_process();
				}
			} else if (LINE_NUM>2)
			{
				// load each instruction, handle them one by one
				iss>>PRO_NUM;
				iss>>do_task;
				iss>>VIRTUAL_MEMORY;
				cout<<endl<<"Process "<<PRO_NUM<<" requests "<<do_task<<" "<<VIRTUAL_MEMORY<<endl;
				uint32_t THE_PAGE = floor(VIRTUAL_MEMORY/PAGE_SIZE);
				cout<<"Page number: "<<THE_PAGE<<endl;
				if (!check_load(PRO_NUM,THE_PAGE)) 
				{
					cout<<"Page fault ..."<<endl;
					find_insert_pos(PRO_NUM,THE_PAGE);
					cout<<"Loading page "<<THE_PAGE<<" of process "<<PRO_NUM<<" into frame "<<FRAME_FOR_LOAD<<endl;
					cout<<"Frame number: "<<FRAME_FOR_LOAD<<endl;
				} else 
				{
					FRAME_FOR_LOAD = P_list[PRO_NUM].Page_Table[THE_PAGE].get_fn();
					cout<<"Frame number: "<<FRAME_FOR_LOAD<<endl;			
				}
				
				uint32_t DIFF = VIRTUAL_MEMORY%PAGE_SIZE;

				uint32_t PHYSICAL_MEMORY=PAGE_SIZE*FRAME_FOR_LOAD+DIFF;
				cout<<"Physical address: "<<PHYSICAL_MEMORY<<endl;
				if(PHYSICAL_MEMORY>128 or VIRTUAL_MEMORY>512) 
				{
					cerr<<"PHYSICAL_MEMORY or VIRTUAL_MEMORY is out of range."<<endl;
					exit(1);
				} else
				{
					operate(do_task, THE_PAGE);

					// print table
					cout<<"Page Tables (with aging status)"<<endl;
					for (uint32_t i=0; i<LST_SIZE; i++)
					{
						cout<<"Process "<<i<<endl;
						P_list[i].print_process();
					}
				}
			}
			LINE_NUM++;
		}
	}
}