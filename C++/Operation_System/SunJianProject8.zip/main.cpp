// Jian Sun Project 8 -- Page System Simulation
// main function

#include <stdio.h>
#include <Counter.h>
#include <Process.h>
#include <PageTableEntry.h>
#include <PagingSimulator.h>

int main(int argc, char *argv[])
{
	// to check if the argument number is correct
	if (argc!=2) 
	{
     cerr << "Please write down sth like an input address.\n";
     exit(1);
    }

	// define PagingSimulator class here and load file into the class
	PagingSimulator* ps = new PagingSimulator(argv[1]);

    // run class
    ps->run();
    
    // release memory
    ps->~PagingSimulator();  
}
