// Jian Sun Project 8 -- Page System Simulation
// PagingSimulator Class

#ifndef PAGINGSIMULATOR_H
#define PAGINGSIMULATOR_H

#include "Process.h"
#include <math.h>

class PagingSimulator
{
public:
	PagingSimulator(string fn);				// Constructor with one argument fn (fn means filename)
	~PagingSimulator();						// Destructor, release memory
	void run();								// required function run()

private:
	string filename;						// loaded file name
	string do_task;							// loaded specific task r or w
	int LINE_NUM=1;							// line number index
	int ROUND_CNT=0;						// the counter will be updated every other instruction. ROUND_CNT is used to count dealed instructions 
	uint32_t PRO_NUM=0;						// loaded process number
	uint32_t PAGE_NUMBER;					// loaded page number
	uint32_t FRAME_NUMBER;					// loaded frame number
	uint32_t PAGE_SIZE;						// loaded each page frame size
	uint32_t VIRTUAL_MEMORY;				// loaded virtual memory
	uint32_t FRAME_INEX=0;					// assign frame number to FRAME_FOR_LOAD before 4
	uint32_t FRAME_FOR_LOAD=0;				// the frame for loading this time
	
	uint32_t LAST_FN=UINT32_MAX;			// the frame number dealed last time
	uint32_t LAST_PN;						// the page number dealed last time
	uint32_t LAST_PRO;						// the process number dealed last time

	uint32_t PRO_DROP=UINT32_MAX;			// the process number of evicted frame this time
	uint32_t PAGE_DROP=UINT32_MAX;			// the page number of evicted frame this time
	
	Process *P_list = new Process[100];		// dynamic array of processes
	
	// the map of loaded frame list, the key value is a tuple of process_number and page_number
	// the value value is a tuple of frame_number and counter
	map<tuple<uint32_t,uint32_t>, tuple<uint32_t,uint8_t>> frame_list;
	
	// the function to check if the page in some process is loaded or not
	bool check_load(uint32_t PRON,uint32_t PN);
	
	// the function to update the frame list. Maybe we will evict one.
	void modify_frame_list(uint32_t PRON, uint32_t FN, uint32_t PN, Counter c);  
	
	// the function to find proper frame number to load page
	void find_insert_pos(uint32_t PRON,uint32_t PN);

	// the function to return the frame number to evict. the arguement is frame list
	uint32_t sort_frame_list(map<tuple<uint32_t,uint32_t>, tuple<uint32_t,uint8_t>> FLST);
	
	// the function to operate each loaded instruction, the arguement is task and page number
	void operate(string task, uint32_t PN);
};

#endif // PAGINGSIMULATOR_H