// Jian Sun Project 8 -- Page System Simulation
// PageTableEntry Class

#include "PageTableEntry.h"

PageTableEntry::PageTableEntry(uint32_t BITS_NUM)
{
	FRAME_NUM=BITS_NUM;
}

PageTableEntry::~PageTableEntry()
{
}

uint32_t PageTableEntry::get_pn()
{
	return PAGE_NUM;
}

uint32_t PageTableEntry::get_fn()
{
	return FRAME_NUM;
}

uint32_t PageTableEntry::get_M()
{
	return M;
}

bool PageTableEntry::get_load()
{
	return loaded;
}

void PageTableEntry::page_num(uint32_t P_N)
{
	PAGE_NUM=P_N;
}

void PageTableEntry::new_R(uint32_t R_NUM)
{
	R=R_NUM;
}

void PageTableEntry::new_M(uint32_t M_NUM)
{
	M=M_NUM;
}

void PageTableEntry::new_P(uint32_t P_NUM)
{
	P=P_NUM;
}

void PageTableEntry::frame_num(uint32_t F_NUM)
{
	FRAME_NUM=F_NUM;
}

void PageTableEntry::new_load()
{
	loaded=true;
}

void PageTableEntry::reset()
{
	R=0;
	M=0;
	P=0;
	FRAME_NUM=0;
	loaded=false;
}

void PageTableEntry::print_PTE()
{
	string page_number = to_string(PAGE_NUM)+":";
	cout<<left<<page_number<<"\t"<<R<<"\t"<<M<<"\t"<<P<<"\t"<<FRAME_NUM<<"\t";
}
