// Jian Sun Project 8 -- Page System Simulation
// PageTableEntry Class

#ifndef PAGETABLEENTRY_H
#define PAGETABLEENTRY_H

#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <cmath> 
#include <list>
#include <vector>
#include <stdio.h>
#include <cstdlib>
#include <unistd.h>
#include <stdlib.h>
#include <algorithm>
#include <string>

using namespace std;
using std::setw;

class PageTableEntry
{
public:
	PageTableEntry(uint32_t BITS_NUM=0);	// Constructor
	~PageTableEntry();	
	uint32_t get_pn();						// function to return page number
	uint32_t get_fn();						// function to return frame number
	uint32_t get_M();						// function to return modified bit
	bool get_load();						// function to return if this page is loaded or not
					
	void page_num(uint32_t P_N);			// change page number
	void new_R(uint32_t R_NUM);				// change Referenced bit
	void new_M(uint32_t M_NUM);				// change Modified bit
	void new_P(uint32_t P_NUM);				// change present/absent bit
	void frame_num(uint32_t F_NUM);			// chagne frame number
	void new_load();						// change loaded value
	void reset();							// reset all parameters except page number in this class
	void print_PTE();						// print this page table entry			

private:
	uint32_t PAGE_NUM=0;					// page number
	uint32_t R=0;							// referenced bit
	uint32_t M=0;							// modified bit
	uint32_t P=0;							// present/absent bit
	uint32_t FRAME_NUM=0;					// frame number
	bool loaded=false;						// loaded index
};

#endif // PAGETABLEENTRY_H
