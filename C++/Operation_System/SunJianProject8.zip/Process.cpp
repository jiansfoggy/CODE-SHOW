// Jian Sun Project 8 -- Page System Simulation
// Memory Chunk Class

#include "Process.h"

Process::Process(uint32_t PN, uint32_t FN)
{
	PAGE_NUM=PN;
	FRAME_NUM=FN;

	// initialize the page table and counter set
	for(uint32_t i=0; i<PN; i++)
	{
		transit_table = new PageTableEntry(0);
		transit_table->page_num(i);
		Page_Table[i] = *transit_table;
		Counter* CC = new Counter();
		cnt_set.insert({i, *CC});
	}
}

Process::~Process()
{
	delete[] Page_Table;
	cnt_set.clear();
}

void Process::print_process()
{
	cout<<left<<"page#\tR\tM\tP\tframe#\taging"<<endl;
	for (uint32_t i=0; i<PAGE_NUM; i++)
	{
		// all pages will be printed
		Page_Table[i].print_PTE();
		// but only loaded pages' counter will be printed
		if (Page_Table[i].get_load())
		{
			cnt_set[i].pnt_CNT(2);
		} else cout<<endl;
	}
}
