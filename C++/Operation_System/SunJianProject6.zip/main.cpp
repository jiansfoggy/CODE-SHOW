#include <stdio.h>
#include "Deadlock_Detect.h"

int main(int argc, char *argv[])
{
	// to check if the argument number is correct
	if (argc!=2) {
      cerr << "Please write down sth like an input address.\n";
      exit(1);
    }

    // define Deadlock_Detect class here and load file into the class
    Deadlock_Detect* dd = new Deadlock_Detect(argv[1]);

    // run class
    (*dd).run();

    // release memory
    (*dd).~Deadlock_Detect();
}
