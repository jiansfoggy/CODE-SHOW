#include "Deadlock_Detect.h"

Deadlock_Detect::Deadlock_Detect(string filename){
	// read file
	ifstream file_stream(filename);
	if(!file_stream.is_open()){
		cerr << "failed to open " << filename << endl;
		exit(1);
	} else{
		string loaded_line;
		int LINE_NUM=1;
		int LOAD_NUM;
		vector<int> transit;
		while(getline(file_stream, loaded_line)){
			istringstream iss(loaded_line);
			// save values like process number, resource type,
			// Current Allocation Matrix, Request Matrix and calculate Available Resource Vector
			if (LINE_NUM==1){
				iss>>P_NUM;
				iss>>R_TYPE;
				UNMARKED_NUM=P_NUM;
				cout<<"Initial Values:"<<endl;
				cout<<"Number of processes: "<<P_NUM<<endl;
				cout<<"Number of resource types: "<<R_TYPE<<endl;
				cout<<"Existing Resource Vector"<<endl;
			} else if (LINE_NUM==2){
				while(iss>>LOAD_NUM){
					EXIST.push_back(int(LOAD_NUM));
					cout<<LOAD_NUM<<" ";
				}
				if (int(EXIST.size())!=R_TYPE){
					cerr << "existing resource vector has wrong number of resource type" << endl;
					exit(1);
				} else {
					AVAIL=EXIST;
					cout<<endl;
					cout<<"Current Allocation Matrix"<<endl;
				}
			} else if (LINE_NUM>2 && LINE_NUM<=(2+P_NUM)){
				vector<int> transit;
				marked.push_back(false);
				int i=0;
				while(iss>>LOAD_NUM){
					transit.push_back(int(LOAD_NUM));
					cout<<LOAD_NUM<<" ";
					AVAIL.at(i)-=int(LOAD_NUM);
					i++;
				}
				if (int(transit.size())!=R_TYPE){
					cerr << "existing resource vector has wrong number of resource type" << endl;
					exit(1);
				} else {
					CUR_MATRIX[LINE_NUM-3]=transit;
					transit.clear();
					if ((LINE_NUM-2)==P_NUM) cout<<endl<<"Request Matrix"<<endl;
					else cout<<endl;		
				}
			} else if (LINE_NUM>(2+P_NUM) && LINE_NUM<=(2+P_NUM+P_NUM)){
				vector<int> transit;
				while(iss>>LOAD_NUM){
					transit.push_back(int(LOAD_NUM));
					cout<<LOAD_NUM<<" ";
				}
				if (int(transit.size())!=R_TYPE){
					cerr << "existing resource vector has wrong number of resource type" << endl;
					exit(1);
				} else {
					REQ_MATRIX[LINE_NUM-3-P_NUM]=transit;
					transit.clear();
					if ((LINE_NUM-2-P_NUM)==P_NUM) cout<<endl<<"Available Resource Vector"<<endl;
					else cout<<endl;	
				}
			} else{
				cerr << "line number is out of range" << endl;
				exit(1);
			}
			LINE_NUM++;
		}
		for (int i:AVAIL){
			cout<<i<<" ";
		}
		cout<<endl;
	}
}

Deadlock_Detect::~Deadlock_Detect(){
	// release memory here
	marked.clear();	
	EXIST.clear();		
	AVAIL.clear();	
	(*CUR_MATRIX).clear();	
	(*REQ_MATRIX).clear();	
}

bool Deadlock_Detect::compare_vector(vector<int> r_m){
	bool mark=true;
	// the inputted value is each process from Request Matrix
	for (int i=0; i<int(r_m.size()); i++){
		if (r_m.at(i)>AVAIL.at(i)) return false;
	}
	return mark;
}

void Deadlock_Detect::deal_process(){
	// check if certain process can be viewed as marked one
	for (int i=0; i<P_NUM; i++){
		if (!marked.at(i)){
			if (compare_vector(REQ_MATRIX[i])){
				vector<int> this_process=CUR_MATRIX[i];
				for (int j=0; j<R_TYPE; j++){
					AVAIL.at(j)+=this_process.at(j);
				}
				marked.at(i)=true;
				UNMARKED_NUM--;
				cout<<endl<<"Process "<<i<<" marked"<<endl;
				cout<<"Available Resource Vector"<<endl;
				for (int i:AVAIL){
					cout<<i<<" ";
				}
				cout<<endl;
			}
		}
	}
}

void Deadlock_Detect::run(){
	int BEFORE_NUM=2;
	int AFTER_NUM=1;
	while (BEFORE_NUM!=AFTER_NUM){
		BEFORE_NUM=UNMARKED_NUM;
		deal_process();
		AFTER_NUM=UNMARKED_NUM;
	}
	if (AFTER_NUM!=0){
		string output="";
		for (int i=0; i<P_NUM; i++){
			if(!marked.at(i)) output=output+" "+to_string(i);
		}
		cout<<endl<<"System is deadlocked"<<endl;
		cout<<"Deadlocked processes:"<<output<<endl;
	} else cout<<endl<<"System is not deadlocked"<<endl;
}
