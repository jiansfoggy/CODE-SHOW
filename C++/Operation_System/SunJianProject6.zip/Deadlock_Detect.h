#ifndef DEADLOCK_DETECT_H
#define DEADLOCK_DETECT_H

#include <iostream>
#include <fstream>
#include <sstream>
#include <cmath> 
#include <vector>
#include <stdio.h>
#include <cstdlib>
#include <unistd.h>
#include <stdlib.h>
#include <algorithm>
using namespace std;

class Deadlock_Detect
{
public:
	Deadlock_Detect(string filename);
	~Deadlock_Detect();
	void run();

private:
	int P_NUM;											// process number
	int R_TYPE;											// resource type
	vector<bool> marked;								// the list to show processes are marked or not
	vector<int> EXIST;									// existing resource vector
	vector<int> AVAIL;									// available resource vector
	vector<int> *CUR_MATRIX = new vector<int>[100];		// Current Allocation Matrix
	vector<int> *REQ_MATRIX = new vector<int>[100];		// Available Resource Vector
	int UNMARKED_NUM;									// unmarked processes number
	bool compare_vector(vector<int> r_m);				// compare process from Request Matrix with Available Resource Vector
	void deal_process();								// use for loop to check deadlock issue for each process
};

#endif // DEADLOCK_DETECT_H
