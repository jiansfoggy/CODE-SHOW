// Jian Sun Project 1
#include <iostream>
#include <fstream>
#include <sstream>
#include <stack>
#include <string>

using namespace std;

int main(int argc, char* argv[]){
	    // Error Report for wrongl number of input arguments
		if (argc < 1 || argc > 3) {
			std::cerr << "Please write down sth like an input address.\n";
			exit(1);
		}
		// Load and Read file
		std::string ifilename = argv[1];
		std::ifstream istrm(ifilename, std::ifstream::in);
		stack<string> s;
		if (!istrm.is_open()) {
				std::cout << "failed to open " << ifilename << '\n';
			} else {
						// Save line by line into stack s
						for (std::string line; std::getline(istrm, line); ) {
								s.push(line);
							}
			}
		istrm.close();
		int STACK_SIZE = s.size();
		if (argv[2]) {
				// Specify the output filename
				// Error Report for case input filename = output filename
				if (argv[1]==argv[2]){
						std::cerr << "output filename is same to the input filename.\n";
						exit(1);
					} else {
							// Extract value from stack and Write into output file
							std::string ofilename = argv[2];
							std::ofstream ostrm(ofilename, std::ofstream::out);
							for (int i = 0; i < STACK_SIZE; i++){
									ostrm << s.top() << '\n'; 
									s.pop();
									}
					}
				//s.~stack();
			} else {
					// Does not specify output filename
					for (int i = 0; i < STACK_SIZE; i++){
							std::cout << s.top() << endl;
							s.pop();
					}
			}
}