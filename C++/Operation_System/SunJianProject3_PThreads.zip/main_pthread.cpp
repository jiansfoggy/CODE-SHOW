// Jian Sun Project 3 PThread

#include <iostream>
#include <cmath> 
#include <array>
#include <vector>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <algorithm>
using namespace std;

// shared variable
int thread_count{0};
uint64_t FACTOR_NUM{0};
uint64_t FACTOR_SUM{0};
uint64_t* factor_arr = new uint64_t[100];

// create struct thread_args to hold three parameters.
// These three parameters will be called in function save_paramtr.
struct thread_args{
    uint64_t NUM;
    uint64_t STT;
    uint64_t END;
};

// mutex to protect shared data (critical region)
pthread_mutex_t mutex;

void *save_paramtr(void *arg);
void thread_part(uint64_t LOAD_NUM, uint64_t THREAD_NUM);
void test_perfect_num(uint64_t* factor_arr, uint64_t INPUT_NUM);

int main(int argc, char* argv[])
{	// Convert two input value from char* to string to uint64_t.
	// So function thread_part can call them directly.
    string input_num = argv[1];
    string thread_num = argv[2];
    uint64_t strtoull (const char* str, char** endptr, int base);
    uint64_t INPUT_NUM;
    INPUT_NUM = strtoull (input_num.c_str(), NULL, 0);
    uint64_t THREAD_NUM;
    THREAD_NUM = strtoull (thread_num.c_str(), NULL, 0);
	
    // Call this function to count factor number and 
    // insert elements into factor array
    thread_part(INPUT_NUM, THREAD_NUM);

    cout<< "Enter number: " << INPUT_NUM <<endl;
    cout<< "Number of threads: " << THREAD_NUM <<endl;
    // Output each factor and whether or not perfect number here
    test_perfect_num(factor_arr, INPUT_NUM);
    
}

void *save_paramtr(void *arg){
    thread_args transit = *static_cast<thread_args*>(arg);
    uint64_t LOAD_NUM = transit.NUM;
    uint64_t START_PNT = transit.STT;
    uint64_t END_PNT = transit.END;
    pthread_mutex_lock(&mutex);
	// Decide whether or not the number is a factor of inputted number.
    for (uint64_t i=START_PNT; i<END_PNT; i++){      
        if (LOAD_NUM%i==0) {
            factor_arr[FACTOR_NUM] = i;
            FACTOR_NUM++;
        }      
    }
    pthread_mutex_unlock(&mutex);
    pthread_exit(0);
}

void thread_part(uint64_t LOAD_NUM, uint64_t THREAD_NUM){
    uint64_t MAX_SEARCH = round(LOAD_NUM+1/2);
    uint64_t CHUNK_VAL = (round(MAX_SEARCH/THREAD_NUM)>1)?round(MAX_SEARCH/THREAD_NUM):1;
	pthread_t tid[THREAD_NUM];
	
	// Initial struct thread_args here
    thread_args args [THREAD_NUM];
	
	// Initial mutex
    pthread_mutex_init(&mutex, NULL);
	
    for (uint64_t j = 0; j < THREAD_NUM; j++){
        args[j].NUM = LOAD_NUM;
        if (j==0) args[j].STT=1;
        else args[j].STT=args[j-1].END;
        if (args[j].STT<MAX_SEARCH) {
            args[j].END = ((args[j].STT + CHUNK_VAL)<MAX_SEARCH)?(args[j].STT+CHUNK_VAL):MAX_SEARCH;
            int status = pthread_create(&tid[j], NULL, &save_paramtr, &args[j]);    
            if (status != 0){
                cerr << "Unable to create thread" << endl;
            }
        }       
    }  
    for (uint64_t z = 0; z < THREAD_NUM; z++){
        pthread_join(tid[z], NULL);
    }  
}

void test_perfect_num(uint64_t* factor_arr, uint64_t INPUT_NUM){
    cout<<"Number of factors is: "<<FACTOR_NUM<<endl;
    for (uint64_t i=0; i<FACTOR_NUM; i++){
        FACTOR_SUM += factor_arr[i];
        cout<< factor_arr[i]<<endl;
    }
    cout<<endl;
    if (INPUT_NUM==FACTOR_SUM) {cout<<INPUT_NUM<<" is a perfect number"<<endl;}
    else {cout<< INPUT_NUM << " is not a perfect number"<<endl;}
}