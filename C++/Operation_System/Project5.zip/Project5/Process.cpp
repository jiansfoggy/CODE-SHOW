#include "Process.h"

Process::Process(string p_name, int A_T, int T_R_T, int C_B)
{
	process_name = p_name;
	ARR_TIME = A_T;
	TOTAL_RUN_TIME = T_R_T;
	CPU_BURST = C_B;
}

Process::~Process()
{
	process_name.clear();
}

bool Process::can_leave(int CURRENT_TIME)
{
	if (TOTAL_RUN_TIME==ACC_RUN_TIME)
	{
		TURNROUND_TIME=CURRENT_TIME-ARR_TIME;
		return true;
	}
	else return false;
}

int Process::get_arr_t()
{
	return ARR_TIME;
}

int Process::get_cpuB()
{
	return CPU_BURST;
}

int Process::get_t_run_t()
{
	return TOTAL_RUN_TIME;
}

string Process::get_name()
{
	string p_n=process_name;
	return p_n;
}