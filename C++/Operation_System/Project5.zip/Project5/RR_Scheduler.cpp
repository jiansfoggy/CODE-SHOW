#include "RR_Scheduler.h"
#include <fstream>
#include <sstream>
RR_Scheduler::RR_Scheduler(vector<Process*> p_list,int B_T, int Q_T)
{
	process_list = p_list;	// loaded all processes
	BLOCK_TIME = B_T;
	QUANTUM_TIME = Q_T;
}

RR_Scheduler::~RR_Scheduler()
{
	process_list.clear();
	running_queue.clear();
	block_list.clear();
}

void RR_Scheduler::update_queue()
{
    for (int i = LIST_INDEX; i<int(process_list.size()); i++)
    {
    	Process* transit_p1 = process_list[i];
    	if (i==0)
    	{
    		TOTAL_TIME_NOW=(*transit_p1).get_arr_t();
    		running_queue.push_back(transit_p1);
    		LIST_INDEX++;
    	} else
    	{
    		if ((*transit_p1).get_arr_t()<=TOTAL_TIME_NOW)
    		{
    			running_queue.push_back(transit_p1);
    			LIST_INDEX++;
    		}
    	}
    }
}

void RR_Scheduler::current_process(Process* p)
{	
	THIS_TURN_COST = min((*p).REMAIN_TIME_THIS_TURN, (*p).get_cpuB());
	THIS_TURN_COST = min(THIS_TURN_COST, QUANTUM_TIME);
	THIS_TURN_COST = min(THIS_TURN_COST, ((*p).get_t_run_t()-(*p).ACC_RUN_TIME));
	//cout<<"180 30: "<<THIS_TURN_COST<<endl;
	(*p).ACC_RUN_TIME += THIS_TURN_COST;
	update_queue();
	TOTAL_TIME_NOW += THIS_TURN_COST;	
	if (THIS_TURN_COST==(*p).REMAIN_TIME_THIS_TURN)
	{
		if ((*p).can_leave(TOTAL_TIME_NOW))
		{
			update_last=true;
			cout<<TOTAL_TIME_NOW-THIS_TURN_COST<<"\t"<<(*p).get_name()<<"\t"<<THIS_TURN_COST<<"\tT \n";
			TERMINATE_INDEX++;
			running_queue.erase(find(running_queue.begin(), running_queue.end(), p));
			update_block_list(THIS_TURN_COST);
		} else
		{
			update_last=false;
			(*p).REMAIN_TIME_THIS_TURN=INT32_MAX;
			(*p).BLOCK_TM=BLOCK_TIME;
			block_list.push_back(p);
			running_queue.erase(find(running_queue.begin(), running_queue.end(), p));
			//vector<int>::iterator new_end;
			//new_end=remove(running_queue.begin(), running_queue.end(), *p);
			cout<<TOTAL_TIME_NOW-THIS_TURN_COST<<"\t"<<(*p).get_name()<<"\t"<<THIS_TURN_COST<<"\tB \n";
			update_block_list(THIS_TURN_COST);
		}
	}
	else 
	{
		if (THIS_TURN_COST==(*p).get_cpuB())
		{
			if ((*p).can_leave(TOTAL_TIME_NOW))
			{
				update_last=true;
				cout<<TOTAL_TIME_NOW-THIS_TURN_COST<<"\t"<<(*p).get_name()<<"\t"<<THIS_TURN_COST<<"\tT \n";
				TERMINATE_INDEX++;
				update_block_list(THIS_TURN_COST);
				running_queue.erase(find(running_queue.begin(), running_queue.end(), p));
			} else
			{
				update_last=false;
				(*p).BLOCK_TM=BLOCK_TIME;
				block_list.push_back(p);
				running_queue.erase(find(running_queue.begin(), running_queue.end(), p));
				cout<<TOTAL_TIME_NOW-THIS_TURN_COST<<"\t"<<(*p).get_name()<<"\t"<<THIS_TURN_COST<<"\tB \n";
				update_block_list(THIS_TURN_COST);
			}
		} else
		{
			if (THIS_TURN_COST==QUANTUM_TIME)
			{
				if ((*p).can_leave(TOTAL_TIME_NOW))
				{
					update_last=true;
					cout<<TOTAL_TIME_NOW-THIS_TURN_COST<<"\t"<<(*p).get_name()<<"\t"<<THIS_TURN_COST<<"\tT \n";
					TERMINATE_INDEX++;
					running_queue.erase(find(running_queue.begin(), running_queue.end(), p));
					update_block_list(THIS_TURN_COST);
				} else
				{
					(*p).REMAIN_TIME_THIS_TURN=(*p).get_cpuB()-QUANTUM_TIME;
					running_queue.erase(find(running_queue.begin(), running_queue.end(), p));
					update_last=true;
					update_block_list(THIS_TURN_COST);
					//cout<<"180 30: "<<(*p).REMAIN_TIME_THIS_TURN<<endl;
					running_queue.push_back(p);
					Process* p11 = running_queue[0];
					//cout<<"180 30: "<<(*p11).get_name()<<endl;
					if (running_queue[0]==p)
					{
						THIS_TURN_COST += (*p).REMAIN_TIME_THIS_TURN;
						TOTAL_TIME_NOW += (*p).REMAIN_TIME_THIS_TURN;
						(*p).REMAIN_TIME_THIS_TURN=INT32_MAX;
						update_queue();
						(*p).BLOCK_TM=BLOCK_TIME;
						cout<<TOTAL_TIME_NOW-THIS_TURN_COST<<"\t"<<(*p).get_name()<<"\t"<<THIS_TURN_COST<<"\tB \n";
						running_queue.erase(find(running_queue.begin(), running_queue.end(), p));	
						block_list.push_back(p);
						update_last=false;
						update_block_list((*p).REMAIN_TIME_THIS_TURN);
					}
					else
					{
						cout<<TOTAL_TIME_NOW-THIS_TURN_COST<<"\t"<<(*p).get_name()<<"\t"<<THIS_TURN_COST<<"\tQ \n";
					}					
				}
			} else
			{
				if (THIS_TURN_COST==((*p).get_t_run_t()-(*p).ACC_RUN_TIME))
				{
					if ((*p).can_leave(TOTAL_TIME_NOW))
					{
						update_last=true;
						running_queue.erase(find(running_queue.begin(), running_queue.end(), p));
						cout<<TOTAL_TIME_NOW-THIS_TURN_COST<<"\t"<<(*p).get_name()<<"\t"<<THIS_TURN_COST<<"\tT \n";
						update_block_list(THIS_TURN_COST);
						TERMINATE_INDEX++;
					} 
				}
			}
		}
	}
}
//	else
//	{
//		cout << "Error happens at RR_Scheduler::current_process.\n";
//    	cerr << "Please input correct process.\n";
//      	exit(1);
//	}


void RR_Scheduler::update_block_list(int THIS_TURN_COST)
{
	if (block_list.empty()==false)
	{
		if (update_last)
		{
			for (int i=0; i<int(block_list.size()); ++i)
			{
				Process* p = block_list[i];
				//cout<<"block time : "<<(*p).BLOCK_TM-THIS_TURN_COST<<endl;
				(*p).BLOCK_TM=(((*p).BLOCK_TM-THIS_TURN_COST)>=0)?((*p).BLOCK_TM-THIS_TURN_COST):0;
				if ((*p).BLOCK_TM==0) 
				{	
					running_queue.push_back(p);
					block_list.erase(block_list.begin()+i);
				}	
			}
		}
		else{
			for (int i=0; i<int(block_list.size()-1); ++i)
			{
				Process* p = block_list[i];
				(*p).BLOCK_TM=(((*p).BLOCK_TM-THIS_TURN_COST)>=0)?((*p).BLOCK_TM-THIS_TURN_COST):0;
				if ((*p).BLOCK_TM==0) 
				{	
					running_queue.push_back(p);
					block_list.erase(block_list.begin()+i);
				}
			}
			update_last=true;
		}
	}
	
}

void RR_Scheduler::test_idle()
{
	if ((running_queue.size()==0) && TERMINATE_INDEX!=int(process_list.size()))
	{	
		int LEFT_TIME = INT32_MAX;
		for (auto i=block_list.begin(); i!=block_list.end(); ++i)
		{
			LEFT_TIME = ((*i)->BLOCK_TM<=LEFT_TIME)?(*i)->BLOCK_TM:LEFT_TIME;		
		}
		
		if (LIST_INDEX<int(process_list.size()))
		{
			Process* vp = process_list[LIST_INDEX];
			LEFT_TIME=(((*vp).get_arr_t()-TOTAL_TIME_NOW)<=LEFT_TIME)?((*vp).get_arr_t()-TOTAL_TIME_NOW):LEFT_TIME;
			cout<<TOTAL_TIME_NOW<<"\t[IDLE]\t"<< LEFT_TIME <<"\tI \n";
			TOTAL_TIME_NOW+=LEFT_TIME;
			update_queue();
			update_block_list(LEFT_TIME);
			
		} else 
		{
			cout<<TOTAL_TIME_NOW<<"\t[IDLE]\t"<< LEFT_TIME <<"\tI \n";
			TOTAL_TIME_NOW+=LEFT_TIME;
			update_queue();
			update_block_list(LEFT_TIME);
		}
	}
}	



void RR_Scheduler::run()
{	int FIRST_STT_TIME=INT32_MAX;
	for (auto i=process_list.begin(); i!=process_list.end(); ++i)
	{
		FIRST_STT_TIME=((*i)->get_arr_t()<=FIRST_STT_TIME)?(*i)->get_arr_t():FIRST_STT_TIME;

	}
	TOTAL_TIME_NOW += FIRST_STT_TIME;
	update_queue();
	while(1)
	{
		for (int i=0; i<running_queue.size(); i++)
		{
			current_process(running_queue.at(0));			
			//update_block_list(THIS_TURN_COST);
			test_idle();
//			cout<<"after test_idle"<<endl;
//			cout<<"running_queue.size: "<<running_queue.size()<<endl;
		}

		if (TERMINATE_INDEX==int(process_list.size()))
		{
			cout<<TOTAL_TIME_NOW<<"\t[END]"<<endl;
			for (auto i=process_list.begin(); i!=process_list.end(); ++i)
			{
				cout<<(*i)->get_name()<<"\t"<<(*i)->TURNROUND_TIME<<endl;
				T_TURNROUND_TIME +=(*i)->TURNROUND_TIME;
			}
			break;
		}
	}
	cout<<T_TURNROUND_TIME/LIST_INDEX<<endl;
	exit(1);
}

// void RR_Scheduler::update_queue()
// {
// 	for (auto i=process_list.begin(); i!=process_list.end(); ++i)
// 	{
// 		if (TOTAL_TIME_NOW==(*i)->get_arr_t())
// 		{
// 			running_queue.push_back(*i);
// 			LIST_INDEX++;
// 			//cout<<"running size: "<<running_queue.size()<<endl;
// 		}
// 	}
// }

// if ((running_queue.size()==1) && (running_queue.size()>0)) 
// 			{
// 				this->current_process(Process* p);
// 			}
// 			else
// 			{
// 				update_last=true;
// 				cout<<TOTAL_TIME_NOW-THIS_TURN_COST<<"\t"<<(*p).get_name()<<"\t"<<THIS_TURN_COST<<"\tQ \n";
// 				running_queue.erase(find(running_queue.begin(), running_queue.end(), p));	
// 				running_queue.push_back(p);
// 			}


	// for (auto i=process_list.begin(); i!=process_list.end(); ++i)
	// {
	// 	FIRST_STT_TIME=((*i)->get_arr_t()<=FIRST_STT_TIME)?(*i)->get_arr_t():FIRST_STT_TIME;
	// 	cout<<FIRST_STT_TIME<<endl;
	// }
