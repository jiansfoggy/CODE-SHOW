#ifndef RR_SCHEDULER_H
#define RR_SCHEDULER_H
#include <queue>
#include "Process.h"

class RR_Scheduler
{
public:
	RR_Scheduler(vector<Process*> p_list , int B_T, int Q_T);
	~RR_Scheduler();
	void run();

private:
	vector<Process*> process_list;		// loaded all processes
	int BLOCK_TIME;
	int QUANTUM_TIME;
	bool update_last=true;
	int LIST_INDEX=0;					// to count how many processes are pushed into queue
	int TERMINATE_INDEX=0; 				// count terminated processes number
	int T_TURNROUND_TIME=0;				// total turnround time
	int THIS_TURN_COST;					// the time cost for this part 
	int TOTAL_TIME_NOW=0;				// total running time since 0 msec
	vector<Process*> running_queue;		// active processes
	vector<Process*> block_list;		// blocked processes
	void update_queue(); 				// add or delete process from the running_queue
	void current_process(Process* p);	// running one process per time
	void update_block_list(int THIS_TURN_COST); // add or delete blocked processes
	void test_idle();					// test to process IDLE case or not and update running and blocked processes
};

#endif // RR_SCHEDULER_H