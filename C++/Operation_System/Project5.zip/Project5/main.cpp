#include <stdio.h>
#include "Process.h"
#include "RR_Scheduler.h"

int main(int argc, char **argv)
{
	vector<Process*> processList;
	Process* p1 = new Process("P1", 0, 100, 10);
	(*p1).get_cpuB();
	bool a = (*p1).can_leave(100);
	cout<< a << endl;
	cout<<(*p1).get_cpuB()<<endl;
	cout<<(*p1).get_name()<<endl;
	cout<<(*p1). TURNROUND_TIME<<endl;
	Process* p2 = new Process("P2", 0, 100, 10);
	Process* p3 = new Process("P3", 10, 300, 10);
	processList.push_back(p1);
	processList.push_back(p2);
	processList.push_back(p3);
	Process* k=processList.at(1);
	cout<<"sdaf "<<(*k) . TURNROUND_TIME<<endl;
	int BLOCK_DURATION=5;
	int QUANTUM=20;
	RR_Scheduler* s1 = new RR_Scheduler(processList, BLOCK_DURATION, QUANTUM);
	
}
