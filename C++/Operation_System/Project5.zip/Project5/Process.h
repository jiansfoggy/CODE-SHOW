#ifndef PROCESS_H
#define PROCESS_H

#include <iostream>
#include <cmath> 
#include <vector>
#include <stdio.h>
#include <cstdlib>
#include <unistd.h>
#include <stdlib.h>
#include <algorithm>
using namespace std;

class Process
{
public:
	Process(string p_name, int A_T, int T_R_T, int C_B);
	~Process();
	bool can_leave(int CURRENT_TIME); // Test if can stop running
	int get_arr_t();		// return arrival time
	int get_cpuB();			// return CPU_Burst;
	int get_t_run_t();		// return TOTAL_RUN_TIME;
	string get_name();
	int REMAIN_TIME_THIS_TURN=INT32_MAX; // To signal when this process need to be blocked
	int ACC_RUN_TIME=0;		// Accumulated running time
	int TURNROUND_TIME=0; // To record the turnround time for this process
	int BLOCK_TM=0; // To signal the remaining block_time

private:
	string process_name;
	int ARR_TIME;
	int TOTAL_RUN_TIME;
	int CPU_BURST;
};

#endif // PROCESS_H
