#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include "Process.h"
#include "RR_Scheduler.h"

int main(int argc, char *argv[])
{
	vector<Process*> processList;

	//accept commend line input
	string filename;
	int BLOCK_DURATION;
	int QUANTUM;
	try
	{
		filename = argv[1];
		BLOCK_DURATION = atoi(argv[2]);
		QUANTUM = atoi(argv[3]);
		cout<< BLOCK_DURATION <<" "<< QUANTUM <<endl;
	}
	catch(...)
	{
		cerr<<"Usage:  ./Project5 <filename> <block duration> <QUANTUM>\n";
		exit(1);
	}

	//read the file & create a list of processors
	try
		{
			ifstream file_stream(filename);
			if(!file_stream.is_open())
			{
				throw 0;
			}
			string line;
			string process_name;
			int ARRIVAL_TIME;
			int RUNNING_TIME;
			int BURST_TIME;
			
			while(getline(file_stream, line))
			{
				istringstream iss(line);
				iss >> process_name;
				iss >> ARRIVAL_TIME;
				iss >> RUNNING_TIME;
				iss >> BURST_TIME;
				
				Process* new_process = new Process(process_name, ARRIVAL_TIME, RUNNING_TIME, BURST_TIME);
				processList.push_back(new_process);
			}
			file_stream.close();
		}
		catch(int x)
		{
			cout << "failed to open \"" << filename << "\", ERROR " << x << '\n';
			exit(1);
		}

		//create the scheduler and run it
		
		RR_Scheduler* scheduler_A = new RR_Scheduler(processList, BLOCK_DURATION, QUANTUM);
		scheduler_A->run();

		cout << "something"<< endl;
		//free memory
		(*scheduler_A).~RR_Scheduler();
		return(0);
}