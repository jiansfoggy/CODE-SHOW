// Jian Sun Project 7 Memory Management With Lists
// main function

#include <stdio.h>
#include "MemoryManager.h"
#include "MemoryChunk.h"

int main(int argc, char *argv[])
{
	// to check if the argument number is correct
	if (argc!=2) {
      cerr << "Please write down sth like an input address.\n";
      exit(1);
    }

	// define MemoryManager class here and load file into the class
	MemoryManager* mm = new MemoryManager(argv[1]);

    // run class
    mm->run();

    // release memory
    mm->~MemoryManager();
}
