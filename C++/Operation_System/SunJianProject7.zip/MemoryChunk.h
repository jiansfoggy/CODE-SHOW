// Jian Sun Project 7 Memory Management With Lists
// Memory Chunk Class

#ifndef MEMORYCHUNK_H
#define MEMORYCHUNK_H

#include <iostream>
#include <fstream>
#include <sstream>
#include <cmath> 
#include <list>
#include <vector>
#include <stdio.h>
#include <cstdlib>
#include <unistd.h>
#include <stdlib.h>
#include <algorithm>

using namespace std;

class MemoryChunk
{
public:
	MemoryChunk(string cn, int CS);
	~MemoryChunk();
	string chunk_name;									// the name of this chunk, process or hole
	int STT=0;											// the start place
	int CHUNK_SIZE=0;									// the chunk size
};

#endif // MEMORYCHUNK_H
