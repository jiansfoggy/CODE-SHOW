// Jian Sun Project 7 Memory Management With Lists
// Memory Chunk Class

#include "MemoryChunk.h"

MemoryChunk::MemoryChunk(string cn, int CS)
{
	chunk_name=cn;
	CHUNK_SIZE=CS;
}

MemoryChunk::~MemoryChunk()
{
}