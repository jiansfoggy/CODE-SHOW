// Jian Sun Project 7 Memory Management With Lists
// Memory Manager Class

#ifndef MEMORYMANAGER_H
#define MEMORYMANAGER_H

#include "MemoryChunk.h"

class MemoryManager
{
public:
	MemoryManager(string fn);
	~MemoryManager();	
	void run();

private:
	list<MemoryChunk> PT_List;										// linked list to save running result
	bool ifload=true;												// decide to do load or unload task
	string filename;												// the loaded file name
	string algorithm;												// the loaded algorithm name
	int TOTAL_SIZE;													// total memory size
	int FST_HOLE_POS=0;												// the place for first hole
	int POSITION=0;													// hole position after merging
	MemoryChunk get_ele(list<MemoryChunk> l, int ELEMENT_INDEX);	// extract element at certain position out of a linked list
	void insert_ele(MemoryChunk ck, int ELEMENT_INDEX);				// insert element into linked list at certain position
	void mergehole(int POS);										// the function to merge holes
	void loadF(string process_name, int MEM_SIZE, int HOLE_POS);	// operating loading task
	void unloadF(string process_name);								// operating unloading task
	void firstFitF(string process_name, int MEM_SIZE);				// first fit algorithm
	void bestFitF(string process_name, int MEM_SIZE);				// best fit algorithm
	void worstFitF(string process_name, int MEM_SIZE);				// worst fit algorithm
};

#endif // MEMORYMANAGER_H