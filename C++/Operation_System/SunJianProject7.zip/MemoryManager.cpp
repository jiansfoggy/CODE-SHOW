// Jian Sun Project 7 Memory Management With Lists
// Memory Chunk Class

#include "MemoryManager.h"

MemoryManager::MemoryManager(string fn)
{
	filename=fn;
}
		
MemoryManager::~MemoryManager()
{
	PT_List.clear();
}

MemoryChunk MemoryManager::get_ele(list<MemoryChunk> l, int ELEMENT_INDEX)
{
	if (ELEMENT_INDEX>=int(l.size()))
	{
		cerr << "the index is out of range"<<endl;
      	exit(1);
	}
	else 
	{
		// browse the whole linked list to find the wanted elements
		int i_ele=0;
		for (auto j_ele:l)
		{
			if (i_ele==ELEMENT_INDEX) return j_ele;
			else i_ele++;
		}
		// this cases will not happen, but to avoid warning, we just return the last element here
		return l.back();
	}
}

void MemoryManager::insert_ele(MemoryChunk ck, int ELEMENT_INDEX)
{
	// insert element before position element_index
	list<MemoryChunk>::iterator it1 = PT_List.begin();
   	advance(it1,ELEMENT_INDEX);
	PT_List.insert(it1, ck);
	// delete the original element located at position element_index, now at element_index+1
	list<MemoryChunk>::iterator it2 = PT_List.begin();
   	advance(it2,ELEMENT_INDEX+1);
   	PT_List.erase(it2);
}

void MemoryManager::mergehole(int POS)
{
	// firstly check if the later one is a hole
	if(POS+1<int(PT_List.size()))
	{
		if (get_ele(PT_List,POS+1).chunk_name=="hole")
		{
			MemoryChunk stand_by = get_ele(PT_List,POS);
			stand_by.CHUNK_SIZE+=get_ele(PT_List,POS+1).CHUNK_SIZE;
			insert_ele(stand_by, POS);
			list<MemoryChunk>::iterator range_begin = PT_List.begin();
    		advance(range_begin,POS+1);
			PT_List.erase(range_begin);
			POSITION=POS;
		}	
	} 
	// then check if the former one is a hole
	if(POS-1>=0)
	{
		if (get_ele(PT_List,POS-1).chunk_name=="hole")
		{
			MemoryChunk stand_by = get_ele(PT_List,POS-1);
			stand_by.CHUNK_SIZE+=get_ele(PT_List,POS).CHUNK_SIZE;
			insert_ele(stand_by, POS-1);
			list<MemoryChunk>::iterator range_begin = PT_List.begin();
    		advance(range_begin,POS);
    		PT_List.erase(range_begin);
			POSITION=POS-1;
		}		
	} 
	// coding in this order can avoid the chaos of linked list index
	// and we don't need to change start place
}

void MemoryManager::loadF(string process_name, int MEM_SIZE, int HOLE_POS)
{	
	cout<<endl<<"load "<<process_name<<" "<<MEM_SIZE<<endl;
	MemoryChunk stand_byl = get_ele(PT_List,HOLE_POS);

	if(MEM_SIZE>stand_byl.CHUNK_SIZE)
	{
		cout<<"unable to load process "<<process_name<<endl;
	} else
	{
		MemoryChunk* mc = new MemoryChunk(process_name, MEM_SIZE);
		// check if hole is the only element in the linked list and hole isn't placed NO.1
		if (int(PT_List.size())!=1 && HOLE_POS!=0)
		{
			MemoryChunk former_one = get_ele(PT_List,HOLE_POS-1);
			mc->STT=former_one.STT+former_one.CHUNK_SIZE;
		} else mc->STT=stand_byl.STT;
		
		stand_byl.CHUNK_SIZE -= mc->CHUNK_SIZE;
		stand_byl.STT = mc->STT+mc->CHUNK_SIZE;

		insert_ele(*mc, HOLE_POS);
		
		// check if hole is placed at the end
		// the original position hole_pos is used to place new loaded element
		// so the hole is place at hole_pos+1 now
		if (HOLE_POS+1==int(PT_List.size())) PT_List.push_back(stand_byl);
		else
		{
			list<MemoryChunk>::iterator it3 = PT_List.begin();
   			advance(it3,HOLE_POS+1);
			PT_List.insert(it3, stand_byl);
		}

		if (get_ele(PT_List,HOLE_POS+1).CHUNK_SIZE!=0)
		{
			POSITION=HOLE_POS+1;
			mergehole(POSITION);
			if (algorithm=="firstFit") FST_HOLE_POS=POSITION;
		} else 
		{
			list<MemoryChunk>::iterator it4 = PT_List.begin();
   			advance(it4,HOLE_POS+1);
   			PT_List.erase(it4);

			if (algorithm=="firstFit")
			{
				int k=1;
				int j=0; 
				while(k==1 && j<int(PT_List.size()))
				{
					if (get_ele(PT_List,j).chunk_name=="hole") 
					{
						FST_HOLE_POS=j;
						k++;
					}
					j++;
				}
			}
		}
	}
}

void MemoryManager::unloadF(string process_name)
{
	cout<<endl<<"unload "<<process_name<<endl;
	bool find_this=false;
	for (int i=0; i<int(PT_List.size()); i++)
	{
		MemoryChunk stand_by = get_ele(PT_List,i);
		if(stand_by.chunk_name==process_name)
		{
			stand_by.chunk_name="hole";
			insert_ele(stand_by, i);
			POSITION=i;
			mergehole(POSITION);
			FST_HOLE_POS=(POSITION < FST_HOLE_POS)?POSITION:FST_HOLE_POS;
			find_this=true;
		} 	
	}
	
	if(!find_this) cout<<"cannot unload process "<<process_name<<endl;
}

void MemoryManager::firstFitF(string process_name, int MEM_SIZE)
{
	if (ifload)
	{
		loadF(process_name, MEM_SIZE, FST_HOLE_POS);
	} else unloadF(process_name);

	for (auto i:PT_List)
	{
		cout<<i.chunk_name<<": start "<<i.STT<<", size "<<i.CHUNK_SIZE<<endl;
	}
}
	
void MemoryManager::bestFitF(string process_name, int MEM_SIZE)
{
	if (ifload)
	{
		int MIN_POS=INT32_MAX;
		int MIN_VAL=INT32_MAX;
		int MIN_STT=INT32_MAX;
		for (int i=0; i<int(PT_List.size()); i++)
		{
			MemoryChunk stand_byb = get_ele(PT_List,i);
			if (stand_byb.chunk_name=="hole")
			{
				if (stand_byb.CHUNK_SIZE<=MIN_VAL)
				{
					if((stand_byb.CHUNK_SIZE==MIN_VAL)&&(stand_byb.STT>MIN_STT))
					{
					 	MIN_VAL=stand_byb.CHUNK_SIZE;
					} else
					{
						MIN_POS=i;
					 	MIN_VAL=stand_byb.CHUNK_SIZE;
						MIN_STT=stand_byb.STT;
					}
				}
			}
		}
		if (MIN_POS<int(PT_List.size())) loadF(process_name, MEM_SIZE, MIN_POS);
		else
		{
			cout<<endl<<"load "<<process_name<<" "<<MEM_SIZE<<endl;
			cout<<"unable to load process "<<process_name<<endl;
		}
	} else unloadF(process_name);

	for(auto j:PT_List)
	{
		cout<<j.chunk_name<<": start "<<j.STT<<", size "<<j.CHUNK_SIZE<<endl;
	} 
}

void MemoryManager::worstFitF(string process_name, int MEM_SIZE)
{
	if (ifload)
	{
		int MAX_POS=INT32_MAX;
		int MAX_VAL=-1;
		int MAX_STT=INT32_MAX;
		for (int i=0; i<int(PT_List.size()); i++)
		{
			MemoryChunk stand_byw = get_ele(PT_List,i);
			if (stand_byw.chunk_name=="hole")
			{
				if (stand_byw.CHUNK_SIZE>=MAX_VAL)
				{
					if((stand_byw.CHUNK_SIZE==MAX_VAL)&&(stand_byw.STT>MAX_STT))
					{
					 	MAX_VAL=stand_byw.CHUNK_SIZE;
					} else
					{
						MAX_POS=i;
					 	MAX_VAL=stand_byw.CHUNK_SIZE;
						MAX_STT=stand_byw.STT;
					}
				}
			}
		}
		if (MAX_POS<int(PT_List.size())) loadF(process_name, MEM_SIZE, MAX_POS);
		else
		{
			cout<<endl<<"load "<<process_name<<" "<<MEM_SIZE<<endl;
			cout<<"unable to load process "<<process_name<<endl;
		}
	} else unloadF(process_name);

	for(auto j:PT_List)
	{
		cout<<j.chunk_name<<": start "<<j.STT<<", size "<<j.CHUNK_SIZE<<endl;
	}
}

void MemoryManager::run()
{
	// read file
	ifstream file_stream(filename);
	if(!file_stream.is_open())
	{
		cerr << "failed to open " << filename << endl;
		exit(1);
	} else
	{
		string loaded_line;
		int LINE_NUM=1;
		string operation;
		string P_name;
		int EACH_SIZE;
		while(getline(file_stream, loaded_line))
		{
			istringstream iss(loaded_line);
			if (LINE_NUM==1)
			{
				iss>>algorithm;
				iss>>TOTAL_SIZE;
				MemoryChunk* transit = new MemoryChunk("hole",TOTAL_SIZE);
				cout<<transit->chunk_name<<": start "<<transit->STT<<", size "<<transit->CHUNK_SIZE<<endl;
				PT_List.push_back(*transit);
			} else
			{
				iss>>operation;
				if (operation=="load")
				{
					ifload=true;
					iss>>P_name;
					iss>>EACH_SIZE;
					if (algorithm=="firstFit")
					{
						firstFitF(P_name, EACH_SIZE);	
					} else if (algorithm=="bestFit")
					{
						bestFitF(P_name, EACH_SIZE);
					} else if (algorithm=="worstFit")
					{
						worstFitF(P_name, EACH_SIZE);
					} else cout<<"Please input proper method"<<endl;
				} else if (operation=="unload")
				{
					ifload=false;
					iss>>P_name;
					if (algorithm=="firstFit")
					{
						firstFitF(P_name, 0);	
					} else if (algorithm=="bestFit")
					{
						bestFitF(P_name, 0);
					} else if (algorithm=="worstFit")
					{
						worstFitF(P_name, 0);
					} else cout<<"Please input proper method"<<endl;
				} else cout<<"unrecognized task"<<endl;
			}
			LINE_NUM++;
		}
	}
}
